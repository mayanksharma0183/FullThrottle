from django.apps import AppConfig


class ApiDataConfig(AppConfig):
    name = 'api_data'
